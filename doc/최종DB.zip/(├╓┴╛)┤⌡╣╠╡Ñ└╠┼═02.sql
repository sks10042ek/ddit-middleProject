--PHOTO
CREATE SEQUENCE PH_seq INCREMENT BY 1
       START WITH 1
       MINVALUE 1
       MAXVALUE 9999999999
       NOCYCLE
       NOCACHE
       NOORDER;
       
    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230001_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230001_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230001_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230002_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230002_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230002_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230003_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230003_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230003_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230004_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230004_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230004_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230005_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230005_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230005_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230006_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230006_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230006_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230007_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230007_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230007_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230008_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230008_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230008_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230009_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230009_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230009_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230010_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230010_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230010_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230011_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230011_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230011_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230012_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230012_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230012_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230013_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230013_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230013_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230014_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230014_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230014_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230015_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230015_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230015_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230016_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230016_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230016_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230017_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230017_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230017_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230018_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230018_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230018_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230019_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230019_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230019_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230020_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230020_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230020_3');
-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
	insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230021_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230021_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230021_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230022_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230022_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230022_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230023_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230023_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230023_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230024_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230024_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230024_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230025_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230025_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230025_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230026_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230026_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230026_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230027_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230027_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230027_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230028_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230028_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230028_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230029_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230029_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230029_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230030_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230030_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230030_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230031_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230031_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230031_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230032_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230032_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230032_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230033_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230033_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230033_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230034_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230034_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230034_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230035_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230035_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230035_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230036_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230036_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230036_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230037_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230037_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230037_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230038_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230038_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230038_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230039_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230039_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230039_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230040_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230040_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230040_3');
--------------------------------------------------------------------------------------------------------------------------------------------------    
    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230041_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230041_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230041_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230042_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230042_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230042_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230043_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230043_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230043_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230044_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230044_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230044_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230045_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230045_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230045_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230046_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230046_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230046_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230047_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230047_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230047_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230048_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230048_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230048_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230049_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230049_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230049_3');
	
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230050_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230050_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230050_3');
	
		    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230051_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230051_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230051_3');
	
		    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230052_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230052_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230052_3');
	
		    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230053_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230053_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230053_3');
	
		    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230054_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230054_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230054_3');
	
		    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230055_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230055_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230055_3');
	
		    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230056_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230056_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230056_3');
	
		    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230057_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230057_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230057_3');
	
		    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230058_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230058_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230058_3');
	
		    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230059_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230059_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230059_3');
	
		    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230060_1');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230060_2');
	    insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
    values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJAC230060_3');
    
    INSERT INTO PHOTO (PT_CODE, PT_TYPE, PT_FILE)
SELECT 'J' || LPAD(PH_seq.nextval, 10, '0'), '����', 'JJRM' || LPAD(230001 + LEVEL - 1, 6, '0')
FROM dual
CONNECT BY LEVEL <= 160;

insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230001');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230002');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230003');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230006');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230007');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230008');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230011');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230012');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230013');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230016');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230017');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230018');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230022');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230023');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230024');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230027');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230028');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230029');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230031');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230032');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230033');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230036');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230038');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230039');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230041');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230043');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230044');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230046');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230047');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230048');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230051');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230052');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230053');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230056');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230057');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230058');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230061');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230062');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230063');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230066');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230067');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230068');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230071');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230073');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230074');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230076');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230077');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230078');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230081');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230082');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230085');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230086');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230087');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230088');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230092');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230093');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230094');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230098');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230099');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230100');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230101');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230102');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230103');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230106');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230108');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230109');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230111');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230114');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230115');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230116');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230117');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230118');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230121');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230122');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230123');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230126');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230128');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230129');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230131');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230134');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230135');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230137');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230138');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230139');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230141');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230143');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230144');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230146');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230149');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230150');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230153');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230154');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230155');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230158');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230159');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230160');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230162');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230164');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230165');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230167');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230169');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230170');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230171');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230173');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230174');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230176');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230178');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230179');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230181');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230182');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230183');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230186');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230187');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230188');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230191');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230192');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230194');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230196');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230197');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230199');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230201');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230202');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230203');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230206');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230207');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230208');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230211');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230213');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230214');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230216');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230218');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230219');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230221');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230222');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230223');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230227');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230228');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230229');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230231');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230232');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230235');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230237');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230238');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230240');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230242');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230243');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230244');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230246');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230247');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230248');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230251');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230253');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230254');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230256');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230258');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230259');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230261');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230262');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230263');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230266');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230267');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230268');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230271');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230274');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230275');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230276');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230279');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230280');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230282');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230283');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230285');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230287');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230288');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230290');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230291');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230292');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230293');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230296');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230298');
insert into PHOTO (PT_CODE, PT_TYPE, PT_FILE)
values('J' || lpad(PH_seq.nextval,10,'0'),'����','JJRV230299');




