DROP SEQUENCE ACC_SEQ; 
DROP SEQUENCE BO_SEQ;
DROP SEQUENCE COM_SEQ;
DROP SEQUENCE GB_SEQ;
DROP SEQUENCE MIL_SEQ;
DROP SEQUENCE PAY_SEQ;
DROP SEQUENCE PH_SEQ;
DROP SEQUENCE REF_SEQ;
DROP SEQUENCE RES_SEQ;
DROP SEQUENCE REV_SEQ;
DROP SEQUENCE ROM_SEQ;


DROP TABLE "ACCOMMODATION" CASCADE CONSTRAINTS;
DROP TABLE "BOARD" CASCADE CONSTRAINTS;
DROP TABLE "COMENT" CASCADE CONSTRAINTS;
DROP TABLE "COUPON" CASCADE CONSTRAINTS;
DROP TABLE "CP_HAVING" CASCADE CONSTRAINTS;
DROP TABLE "GROUPBUYING" CASCADE CONSTRAINTS;
DROP TABLE "MEMBER" CASCADE CONSTRAINTS;
DROP TABLE "MILEAGE" CASCADE CONSTRAINTS;
DROP TABLE "PAYMENT" CASCADE CONSTRAINTS;
DROP TABLE "PHOTO" CASCADE CONSTRAINTS;
DROP TABLE "REFUND" CASCADE CONSTRAINTS;
DROP TABLE "RESERVATION" CASCADE CONSTRAINTS;
DROP TABLE "REVIEW" CASCADE CONSTRAINTS;
DROP TABLE "ROOM" CASCADE CONSTRAINTS;
DROP TABLE "SERVICE_LIST" CASCADE CONSTRAINTS;
DROP TABLE "SERVICE_INFO" CASCADE CONSTRAINTS;
DROP TABLE "WISHLIST" CASCADE CONSTRAINTS;   

commit;
   
---------------------------------------------------------------------------------------------------------
--MEMBER 
INSERT INTO member (mem_id, mem_pass, mem_name, mem_email, mem_tel, mem_birth, mem_gender, mem_code, mem_mil, mem_photo)
VALUES ('LittleQueka', '1234', '������', 'little@naver.com', '010-1234-5678', TO_DATE('2000-12-15', 'YYYY-MM-DD'), 'Female','ȸ��', 1000, '');

INSERT INTO member (mem_id, mem_pass, mem_name, mem_email, mem_tel, mem_birth, mem_gender, mem_code, mem_mil, mem_photo)
VALUES ('BigQueka', '1234', '������', 'big@naver.com', '010-9101-1213', TO_DATE('2000-12-16', 'YYYY-MM-DD'), 'Male','ȸ��', 1000, '');

INSERT INTO member (mem_id, mem_pass, mem_name, mem_email, mem_tel, mem_birth, mem_gender, mem_code, mem_mil, mem_photo)
VALUES ('MiddleQueka', '1234', '�ֱ���', 'middle@naver.com', '010-1415-1617', TO_DATE('2000-12-17', 'YYYY-MM-DD'), 'Male','ȸ��', 1000, '');

INSERT INTO member (mem_id, mem_pass, mem_name, mem_email, mem_tel, mem_birth, mem_gender, mem_code, mem_mil, mem_photo)
VALUES ('CutieQueka', '1234', '�ż���', 'cutie@naver.com', '010-1819-2021', TO_DATE('2000-12-18', 'YYYY-MM-DD'), 'Female','ȸ��', 1000, '');

INSERT INTO member (mem_id, mem_pass, mem_name, mem_email, mem_tel, mem_birth, mem_gender, mem_code, mem_mil, mem_photo)
VALUES ('PrettyQueka', '1234', 'Ȳ����', 'pretty@naver.com', '010-2223-2425', TO_DATE('2000-12-19', 'YYYY-MM-DD'), 'Female','ȸ��', 1000, '');

INSERT INTO member (mem_id, mem_pass, mem_name, mem_email, mem_tel, mem_birth, mem_gender, mem_code, mem_mil, mem_photo)
VALUES ('Admin1', '1234', '������1', 'admin1@naver.com', '010-2627-2829', TO_DATE('2000-12-20', 'YYYY-MM-DD'), 'male','������', 1000, '');

commit;
---------------------------------------------------------------------------------------------------------------------------------------------------
--BOARD 
CREATE SEQUENCE bo_seq INCREMENT BY 1
       START WITH 1
       MINVALUE 1
       MAXVALUE 9999
       NOCYCLE
       NOCACHE
       NOORDER;
       
INSERT INTO BOARD (BO_CODE, BO_TYPE, BO_TITLE, BO_CONTENT, BO_DATE, MEM_ID)
VALUES (('JJBO23' || LPAD(BO_SEQ.NEXTVAL,4,'0')), '1:1����', '������ ����ϰ� �;��.', '���� ������ ���Ҹ� ����ϰ� ������, ��� �ؾ��ұ��?','2023-08-05', 'LittleQueka');

INSERT INTO BOARD (BO_CODE, BO_TYPE, BO_TITLE, BO_CONTENT, BO_DATE, MEM_ID)
VALUES (('JJBO23' || LPAD(BO_SEQ.NEXTVAL,4,'0')), '1:1����', '���̵�� ��й�ȣ�� �ؾ����.', 'ȸ�� ������ ���̵�� ��й�ȣ�� �ؾ����.','2023-08-05', 'BigQueka');

INSERT INTO BOARD (BO_CODE, BO_TYPE, BO_TITLE, BO_CONTENT, BO_DATE, MEM_ID)
VALUES (('JJBO23' || LPAD(BO_SEQ.NEXTVAL,4,'0')), '��������', '[��ǥ] 7�� 4�� ���־ �����ϱ� �̺�Ʈ', '??????????�ȳ��ϼ���. ���� ��Դϴ�.
7�� 4�� ���� � �����ϱ� �̺�Ʈ ��÷�ڸ� ��ǥ�մϴ�. ��÷�� : Bi****ka','2023-08-05', 'Admin1');

INSERT INTO BOARD (BO_CODE, BO_TYPE, BO_TITLE, BO_CONTENT, BO_DATE, MEM_ID)
VALUES (('JJBO23' || LPAD(BO_SEQ.NEXTVAL,4,'0')), '��������', '[��ǥ] 8�� 1�� ���־ �����ϱ� �̺�Ʈ', '�ȳ��ϼ���. ���� ��Դϴ�.
7�� 4�� ���� � �����ϱ� �̺�Ʈ ��÷�ڸ� ��ǥ�մϴ�. ��÷�� : Mi*****ka','2023-08-05', 'Admin1');

INSERT INTO BOARD (BO_CODE, BO_TYPE, BO_TITLE, BO_CONTENT, BO_DATE, MEM_ID)
VALUES (('JJBO23' || LPAD(BO_SEQ.NEXTVAL,4,'0')), '�絵����', '�׷��� �Ͼ�Ʈ ���� 8�� 23��~24��(1��2��) �絵�ؿ�.', '���� �������� ����, �絵 �� ����� ã���ϴ�.','2023-08-22', 'LittleQueka');

INSERT INTO BOARD (BO_CODE, BO_TYPE, BO_TITLE, BO_CONTENT, BO_DATE, MEM_ID)
VALUES (('JJBO23' || LPAD(BO_SEQ.NEXTVAL,4,'0')), '�絵����', 'ȣ�� ��ī����ũ ���� 1ȣ�� 8�� 23��~24��(1��2��) �絵�ؿ�', '���� �������� �� ���� ������. �絵 ������ �� ��� ��Ź�����.','2023-08-22', 'BigQueka');

INSERT INTO BOARD (BO_CODE, BO_TYPE, BO_TITLE, BO_CONTENT, BO_DATE, MEM_ID)
VALUES (('JJBO23' || LPAD(BO_SEQ.NEXTVAL,4,'0')), '�絵����', '���� �۷��� ���� 8�� 30��~31��(1��2��) �絵�ؿ�', '���� ���ڱ� ���������� ������ ���ƿ�. �絵 ������ ��~','2023-08-22', 'CutieQueka');

commit;
---------------------------------------------------------------------------------------------------------------------------------------
--COMENT
CREATE SEQUENCE com_seq INCREMENT BY 1
       START WITH 1
       MINVALUE 1
       MAXVALUE 9999
       NOCYCLE
       NOCACHE
       NOORDER;
       
INSERT INTO COMENT (CO_CODE, BO_CODE, CO_CONTENT)
VALUES ('JJCO23' || LPAD(COM_SEQ.NEXTVAL,4,'0'), 'JJBO230001', '������Ҵ�  Ȩ������ > ���������� > ���೻������ ���� �����մϴ�. �����մϴ�.');

INSERT INTO COMENT (CO_CODE, BO_CODE, CO_CONTENT)
VALUES ('JJCO23' || LPAD(COM_SEQ.NEXTVAL,4,'0'), 'JJBO230002', 'ȸ�� ���� ������ Ȩ������ > ���������� > �� ���� �������� ȸ�������� ������ �� �ֽ��ϴ�. �����մϴ�.');

commit;
---------------------------------------------------------------------------------------------------------------------------------------
--ACCOMODATION
 create sequence acc_seq         
   increment by 1         
   start with 1         
   minvalue 1         
   maxvalue 9999         
   nocycle         
   nocache         
   noorder;         
            
   insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
   values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�׷��� �Ͼ�Ʈ ����','���ֽ�','010-4455-9999' ,0,'1500','1100','ȣ��');  
   
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'ȣ�� ��ī����ũ ���� 1ȣ��','���ֽ�','010-2525-6464' ,0,'1500','1100','ȣ��');  
   
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �۷��� ����','���ֽ�','010-1155-2626' ,0,'1500','1100','ȣ��');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'ȣ�� ����','���ֽ�','010-1212-8897' ,0,'1500','1100','ȣ��');  

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �Ƹ𷺽� ����Ʈ','���ֽ�','010-2244-7897' ,0,'1300','1100','ȣ��');  

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'������� ȣ��','��������','010-2222-5555' ,0,'1500','1100','ȣ��');  

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'ȣ�� �����丮','��������','010-8877-4949' ,0,'1500','1100','ȣ��'); 
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�Ž�ȣ�� ���ֿ���','��������','010-5252-6666' ,0,'1500','1100','ȣ��'); 
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'��ũ ������ ����','��������','010-7877-2252' ,0,'1300','1100','ȣ��');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�� �׷��� ������','��������','010-2252-3333' ,0,'1200','1100','ȣ��');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'��ž��������ȣ�� �����Դ�','����','010-4455-8888' ,0,'1500','1100','ȣ��'); 

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���ߵ��� ȣ��','����','010-5522-7788' ,0,'1500','1100','ȣ��'); 
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�ҳ뺧 ����','����','010-7878-4455' ,0,'1500','1100','ȣ��');
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�ִн� ���� ��������','����','010-8855-1166' ,0,'1200','1200','ȣ��');  
 
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�Ƹ��ٿ� ����Ʈ','����','010-0948-8855' ,0,'1200','1200','ȣ��');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���ο����Ƴ� ȣ��','����','010-4455-8856' ,0,'1500','1100','ȣ��'); 

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���ڱ׸�����Ʈ','����','010-6585-4544' ,0,'1500','1100','ȣ��'); 
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �������̼��߸� ȣ��','����','010-0012-4545' ,0,'1500','1100','ȣ��');
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�ھ���Ƽȣ�� ����','����','010-8899-2626' ,0,'1200','1100','ȣ��'); 
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�ڵ����� ����Ʈ','����','010-9986-4545' ,0,'1300','1100','ȣ��');  
  
  -----------------ȣ��
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �����Ͽ콺 ���','���ֽ�','010-8856-9595' ,0,'1600','1100','���'); 
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'��� ��������','���ֽ�','010-7878-9515' ,0,'1600','1100','���');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �ֿ��縮��','���ֽ�','010-6622-2454' ,0,'1600','1100','���');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���ֳ���Ǯ����','���ֽ�','010-9514-5485' ,0,'1500','1100','���'); 

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���ֱ渮����Ʈ���','���ֽ�','010-9452-2584' ,0,'1500','1100','���'); 
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �������� �볪�����','��������','010-2232-5656' ,0,'1600','1100','���');  
    
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'������ ��������� ���','��������','010-8585-8877' ,0,'1600','1100','���');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'������ ���ֿ÷���','��������','010-2232-5656' ,0,'1600','1100','���');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'Ǯ�����̻��','��������','010-6542-2892' ,0,'1500','1100','���');  

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'JBǮ����','��������','010-6323-5475' ,0,'1500','1100','���');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� ƾ��Ÿ��','����','010-1515-9292' ,0,'1600','1100','���');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �����ϵ� Ǯ����','����','010-1515-9292' ,0,'1600','1100','���');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�쵵 �ϾἺ ���','����','010-5544-8872' ,0,'1600','1100','���'); 
  
insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'��ũ����','����','010-0121-0011' ,0,'1500','1100','���');  

insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���̺��� Ǯ����','����','010-5544-1121' ,0,'1500','1100','���');
  
    insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �ٴٱ׸� ���','����','010-4445-8885' ,0,'1600','1100','���');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �ٸ�ä ��üǮ����','����','010-6565-9514' ,0,'1600','1100','���');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �ֿ��ٴ�������','����','010-2585-3369' ,0,'1600','1100','���'); 
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�����̵�ص�Ǯ����','����','010-0147-5485' ,0,'1500','1100','���');  

insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�ٲ�Ǯ����','����','010-2418-0045' ,0,'1500','1100','���');
  
  ---------------���
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� ���� ȣ����','���ֽ�','010-1111-4444' ,0,'1500','1000','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� ����Խ�Ʈ�Ͽ콺','���ֽ�','010-2222-8844' ,0,'1500','1000','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� ��� ����','���ֽ�','010-4465-9999' ,0,'1500','1100','����'); 

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �㽺����','���ֽ�','010-4466-9999' ,0,'1500','1100','����');  

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'������ �� ����','���ֽ�','010-4467-9999' ,0,'1500','1100','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'����ǳ��','��������','010-2525-7575' ,0,'1500','1000','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'����HY ���� ȣ����','��������','010-2525-3321' ,0,'1500','1000','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� ���س��μ� ���� �ѿ�','��������','010-5555-3354' ,0,'1500','1000','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�÷���','��������','010-4468-9999' ,0,'1500','1100','����');  

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���̾غ�','��������','010-4469-9999' ,0,'1500','1100','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �Ͷ� �Խ�Ʈ�Ͽ콺','����','010-7788-5555' ,0,'1500','1000','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�Ѹ��� ����','����','010-8858-4444' ,0,'1500','1000','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �Ͽ��Ͽ�','����','010-0223-6625' ,0,'1500','1000','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'��������','����','010-4465-9999' ,0,'1500','1100','����');  

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'��Ƽ��Ƽ �Խ�Ʈ�Ͽ콺','����','010-4465-9999' ,0,'1500','1100','����');
  
    insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� ���� �Խ�Ʈ�Ͽ콺','����','010-1122-4475' ,0,'1500','1000','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� 6758','����','010-8899-4444' ,0,'1500','1000','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'���� �ѿ�������','����','010-4456-5568' ,0,'1500','1000','����');  
  
  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'�ʸ� �� �Ͽ콺','����','010-4465-9999' ,0,'1500','1100','����'); 

  insert into accommodation (a_code, a_name, a_addr, a_tel, a_wnum, a_entime, a_extime, a_type)         
  values('JJAC23' || lpad(acc_seq.nextval,4,'0'),'��������','����','010-4465-9999' ,0,'1500','1100','����');
  
  --����
COMMIT;
---------------------------------------------------------------------------------------------------------------------------------
--MILEAGE
CREATE SEQUENCE mil_seq INCREMENT BY 1
       START WITH 1
       MINVALUE 1
       MAXVALUE 99999
       NOCYCLE
       NOCACHE
       NOORDER;
                        

   
   commit;
   -----------------------------------------------------------------------------------
--ROOM

CREATE SEQUENCE rom_seq INCREMENT BY 1
       START WITH 1
       MINVALUE 1
       MAXVALUE 9999
       NOCYCLE
       NOCACHE
       NOORDER;
       
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230001','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230001','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230001','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230001','����Ʈ','2', '3', '550000', '5');  
    
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230002','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230002','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230002','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230002','����Ʈ','2', '3', '550000', '5');  
    
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230003','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230003','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230003','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230003','����Ʈ','2', '3', '550000', '5');  
    
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230004','���Ĵٵ�','1', '2', '250000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230004','���۸���','1', '2', '350000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230004','�𷰽�','2', '3', '450000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230004','����Ʈ','2', '3', '550000', '5'); 

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230005','���Ĵٵ�','1', '2', '250000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230005','���۸���','1', '2', '350000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230005','�𷰽�','2', '3', '450000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230005','����Ʈ','2', '3', '550000', '5'); 
    
            insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230006','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230006','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230006','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230006','����Ʈ','2', '3', '550000', '5');  
    
            insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230007','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230007','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230007','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230007','����Ʈ','2', '3', '550000', '5');  
    
            insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230008','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230008','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230008','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230008','����Ʈ','2', '3', '550000', '5');  
    
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230009','���Ĵٵ�','1', '2', '250000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230009','���۸���','1', '2', '350000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230009','�𷰽�','2', '3', '450000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230009','����Ʈ','2', '3', '550000', '5'); 

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230010','���Ĵٵ�','1', '2', '250000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230010','���۸���','1', '2', '350000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230010','�𷰽�','2', '3', '450000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230010','����Ʈ','2', '3', '550000', '5'); 
    
            insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230011','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230011','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230011','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230011','����Ʈ','2', '3', '550000', '5');  
    
            insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230012','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230012','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230012','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230012','����Ʈ','2', '3', '550000', '5'); 
    
            insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230013','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230013','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230013','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230013','����Ʈ','2', '3', '550000', '5');  
    
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230014','���Ĵٵ�','1', '2', '250000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230014','���۸���','1', '2', '350000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230014','�𷰽�','2', '3', '450000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230014','����Ʈ','2', '3', '550000', '5'); 

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230015','���Ĵٵ�','1', '2', '250000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230015','���۸���','1', '2', '350000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230015','�𷰽�','2', '3', '450000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230015','����Ʈ','2', '3', '550000', '5'); 
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230016','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230016','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230016','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230016','����Ʈ','2', '3', '550000', '5'); 
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230017','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230017','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230017','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230017','����Ʈ','2', '3', '550000', '5'); 
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230018','���Ĵٵ�','1', '2', '250000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230018','���۸���','1', '2', '350000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230018','�𷰽�','2', '3', '450000', '5');  
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230018','����Ʈ','2', '3', '550000', '5'); 
    
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230019','���Ĵٵ�','1', '2', '250000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230019','���۸���','1', '2', '350000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230019','�𷰽�','2', '3', '450000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230019','����Ʈ','2', '3', '550000', '5'); 

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230020','���Ĵٵ�','1', '2', '250000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230020','���۸���','1', '2', '350000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230020','�𷰽�','2', '3', '450000', '5'); 
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230020','����Ʈ','2', '3', '550000', '5');         ---- ȣ��
    
    
    
    
    -----ȣ��
    
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230021','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230021','BŸ��','3', '5', '95000', '5'); 
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230022','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230022','BŸ��','3', '5', '95000', '5'); 
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230023','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230023','BŸ��','3', '5', '95000', '5'); 
    
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230024','AŸ��','2', '4', '85000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230024','BŸ��','3', '5', '90000', '5'); 

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230025','AŸ��','2', '4', '125000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230025','BŸ��','3', '5', '110000', '5'); 
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230026','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230026','BŸ��','3', '5', '95000', '5'); 
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230027','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230027','BŸ��','3', '5', '95000', '5'); 
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230028','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230028','BŸ��','3', '5', '95000', '5'); 
    
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230029','AŸ��','2', '4', '125000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230029','BŸ��','3', '5', '90000', '5'); 

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230030','AŸ��','2', '4', '125000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230030','BŸ��','3', '5', '110000', '5'); 
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230031','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230031','BŸ��','3', '5', '95000', '5'); 
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230032','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230032','BŸ��','3', '5', '95000', '5');
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230033','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230033','BŸ��','3', '5', '95000', '5');
    
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230034','AŸ��','2', '4', '10000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230034','BŸ��','3', '5', '95000', '5'); 

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230035','AŸ��','2', '4', '85000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230035','BŸ��','3', '5', '90000', '5'); 

    
         insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230036','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230036','BŸ��','3', '5', '95000', '5');
    
         insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230037','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230037','BŸ��','3', '5', '95000', '5');
    
         insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230038','AŸ��','2', '4', '75000', '5'); 
        insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230038','BŸ��','3', '5', '95000', '5');
    
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230039','AŸ��','2', '4', '95000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230039','BŸ��','3', '5', '130000', '5'); 

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230040','AŸ��','2', '4', '155000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230040','BŸ��','3', '5', '140000', '5');   

    -----------���
    
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230041','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230041','4�ν�(����)','3', '4', '35000', '5');
    
         insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230042','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230042','4�ν�(����)','3', '4', '35000', '5');


     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230043','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230043','4�ν�(����)','3', '4', '35000', '5');

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230044','4�ν�(����)','3', '4', '35000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230044','4�ν�(����)','3', '4', '35000', '5');

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230045','4�ν�(����)','3', '4', '35000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230045','4�ν�(����)','3', '4', '35000', '5');


     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230046','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230046','4�ν�(����)','3', '4', '35000', '5');


     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230047','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230047','4�ν�(����)','3', '4', '35000', '5');


     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230048','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230048','4�ν�(����)','3', '4', '35000', '5');

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230049','4�ν�(����)','3', '4', '35000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230049','4�ν�(����)','3', '4', '35000', '5');

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230050','4�ν�(����)','3', '4', '35000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230050','4�ν�(����)','3', '4', '35000', '5');


     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230051','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230051','4�ν�(����)','3', '4', '35000', '5');


     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230052','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230052','4�ν�(����)','3', '4', '35000', '5');
    
         insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230053','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230053','4�ν�(����)','3', '4', '35000', '5');
    
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230054','4�ν�(����)','3', '4', '35000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230054','4�ν�(����)','3', '4', '35000', '5');

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230055','4�ν�(����)','3', '4', '35000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230055','4�ν�(����)','3', '4', '35000', '5');

    
         insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230056','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230056','4�ν�(����)','3', '4', '35000', '5');
    
         insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230057','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230057','4�ν�(����)','3', '4', '35000', '5');
    
             insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230058','4�ν�(����)','3', '4', '35000', '5'); 
     insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
    values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230058','4�ν�(����)','3', '4', '35000', '5');
    
    insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230059','4�ν�(����)','3', '4', '35000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230059','4�ν�(����)','3', '4', '35000', '5');

insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230060','4�ν�(����)','3', '4', '35000', '5');
insert into ROOM (R_CODE, A_CODE, R_TYPE, R_MIN, R_MAX, R_PRICE, R_INVEN)
values('JJRM23' || lpad(rom_seq.nextval,4,'0'),'JJAC230060','4�ν�(����)','3', '4', '35000', '5');          --�Խ�Ʈ �Ͽ콺



commit;
----------------------------------------------------------------------------------------------------
