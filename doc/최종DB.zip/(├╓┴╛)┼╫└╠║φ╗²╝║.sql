--------------------------------------------------------
--  ������ ������ - �����-8��-19-2023   
--------------------------------------------------------
--------------------------------------------------------
--  DDL for Table ACCOMMODATION
--------------------------------------------------------

  CREATE TABLE "ACCOMMODATION" 
   (	"A_CODE" VARCHAR2(10), 
	"A_NAME" VARCHAR2(50), 
	"A_ADDR" VARCHAR2(200), 
	"A_TEL" VARCHAR2(20), 
	"A_WNUM" NUMBER(4,0), 
	"A_ENTIME" VARCHAR2(10), 
	"A_EXTIME" VARCHAR2(10), 
	"A_TYPE" VARCHAR2(10)
   ) ;
--------------------------------------------------------
--  DDL for Table BOARD
--------------------------------------------------------

  CREATE TABLE "BOARD" 
   (	"BO_CODE" VARCHAR2(10), 
	"BO_TYPE" VARCHAR2(20), 
	"BO_TITLE" VARCHAR2(100), 
	"BO_CONTENT" CLOB, 
	"BO_DATE" DATE, 
	"MEM_ID" VARCHAR2(30)
   ) ;
--------------------------------------------------------
--  DDL for Table COMENT
--------------------------------------------------------

  CREATE TABLE "COMENT" 
   (	"CO_CODE" VARCHAR2(10), 
	"BO_CODE" VARCHAR2(10), 
	"CO_CONTENT" CLOB
   ) ;
--------------------------------------------------------
--  DDL for Table COUPON
--------------------------------------------------------

  CREATE TABLE "COUPON" 
   (	"CO_CODE" VARCHAR2(10), 
	"CO_NAME" VARCHAR2(30), 
	"CO_RATE" NUMBER(2,0)
   ) ;
--------------------------------------------------------
--  DDL for Table CP_HAVING
--------------------------------------------------------

  CREATE TABLE "CP_HAVING" 
   (	"CO_CODE" VARCHAR2(10), 
	"MEM_ID" VARCHAR2(30), 
	"CP_USE" NUMBER, 
	"CP_DATE" DATE
   ) ;
--------------------------------------------------------
--  DDL for Table GROUPBUYING
--------------------------------------------------------

  CREATE TABLE "GROUPBUYING" 
   (	"GB_CODE" VARCHAR2(10), 
	"GB_CIN" DATE, 
	"GB_COUT" DATE, 
	"GB_RPRICE" NUMBER(10,0), 
	"GB_DPRICE" NUMBER(10,0), 
	"GB_TITLE" VARCHAR2(100), 
	"GB_CONTENT" CLOB, 
	"GB_INVEN" NUMBER(2,0), 
	"GB_DATE" DATE, 
	"MEM_ID" VARCHAR2(20)
   ) ;
--------------------------------------------------------
--  DDL for Table MEMBER
--------------------------------------------------------

  CREATE TABLE "MEMBER" 
   (	"MEM_ID" VARCHAR2(30), 
	"MEM_PASS" VARCHAR2(30), 
	"MEM_NAME" VARCHAR2(40), 
	"MEM_EMAIL" VARCHAR2(50), 
	"MEM_TEL" VARCHAR2(20), 
	"MEM_BIRTH" DATE, 
	"MEM_GENDER" VARCHAR2(10), 
	"MEM_CODE" VARCHAR2(10), 
	"MEM_PHOTO" VARCHAR2(300), 
	"MEM_MIL" NUMBER(8,0)
   ) ;
--------------------------------------------------------
--  DDL for Table MILEAGE
--------------------------------------------------------

  CREATE TABLE "MILEAGE" 
   (	"MIL_CODE" VARCHAR2(10), 
	"MEM_ID" VARCHAR2(30), 
	"MIL_HIS" VARCHAR2(30), 
	"MIL_AMT" NUMBER(10,0), 
	"MIL_TOTAL" NUMBER(10,0), 
	"MIL_DATE" DATE
   ) ;
--------------------------------------------------------
--  DDL for Table PAYMENT
--------------------------------------------------------

  CREATE TABLE "PAYMENT" 
   (	"PAY_NO" VARCHAR2(20), 
	"RES_CODE" VARCHAR2(10), 
	"PAY_DATE" DATE, 
	"PAY_PRICE" NUMBER(10,0), 
	"PAY_METHOD" VARCHAR2(20), 
	"PAY_UID" VARCHAR2(50), 
	"MIL_USE" VARCHAR2(20), 
	"COU_USE" VARCHAR2(20)
   ) ;
--------------------------------------------------------
--  DDL for Table PHOTO
--------------------------------------------------------

  CREATE TABLE "PHOTO" 
   (	"PT_CODE" VARCHAR2(15), 
	"PT_FILE" VARCHAR2(300), 
	"PT_TYPE" VARCHAR2(30)
   ) ;
--------------------------------------------------------
--  DDL for Table REFUND
--------------------------------------------------------

  CREATE TABLE "REFUND" 
   (	"RF_CODE" VARCHAR2(10), 
	"PAY_NO" VARCHAR2(20), 
	"RF_DATE" DATE
   ) ;
--------------------------------------------------------
--  DDL for Table RESERVATION
--------------------------------------------------------

  CREATE TABLE "RESERVATION" 
   (	"RES_CODE" VARCHAR2(10), 
	"R_CODE" VARCHAR2(10), 
	"MEM_ID" VARCHAR2(30), 
	"RES_CIN" DATE, 
	"RES_COUT" DATE, 
	"RES_MEMO" CLOB, 
	"RES_STATUS" VARCHAR2(15)
   ) ;
--------------------------------------------------------
--  DDL for Table REVIEW
--------------------------------------------------------

  CREATE TABLE "REVIEW" 
   (	"REV_CODE" VARCHAR2(10), 
	"RES_CODE" VARCHAR2(10), 
	"REV_DATE" DATE, 
	"REV_SCORE" NUMBER(1,0), 
	"REV_TITLE" CLOB, 
	"REV_CONTENT" CLOB
   ) ;
--------------------------------------------------------
--  DDL for Table ROOM
--------------------------------------------------------

  CREATE TABLE "ROOM" 
   (	"R_CODE" VARCHAR2(10), 
	"A_CODE" VARCHAR2(10), 
	"R_TYPE" VARCHAR2(20), 
	"R_MIN" NUMBER(10,0), 
	"R_MAX" NUMBER(10,0), 
	"R_PRICE" NUMBER(10,0), 
	"R_INVEN" NUMBER(2,0)
   ) ;
--------------------------------------------------------
--  DDL for Table SERVICE_INFO
--------------------------------------------------------

  CREATE TABLE "SERVICE_INFO" 
   (	"SI_CODE" VARCHAR2(10), 
	"SI_NAME" VARCHAR2(20)
   ) ;
--------------------------------------------------------
--  DDL for Table SERVICE_LIST
--------------------------------------------------------

  CREATE TABLE "SERVICE_LIST" 
   (	"A_CODE" VARCHAR2(10), 
	"SI_CODE" VARCHAR2(10)
   ) ;
--------------------------------------------------------
--  DDL for Table WISHLIST
--------------------------------------------------------

  CREATE TABLE "WISHLIST" 
   (	"MEM_ID" VARCHAR2(30), 
	"A_CODE" VARCHAR2(10)
   ) ;

--------------------------------------------------------
--  DDL for Index XPK���ھ�ü
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK���ھ�ü" ON "ACCOMMODATION" ("A_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK�Խ���
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK�Խ���" ON "BOARD" ("BO_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK���
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK���" ON "COMENT" ("CO_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK����
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK����" ON "COUPON" ("CO_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK����_������
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK����_������" ON "CP_HAVING" ("CO_CODE", "MEM_ID", "CP_DATE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK��������
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK��������" ON "GROUPBUYING" ("GB_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPKȸ��
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPKȸ��" ON "MEMBER" ("MEM_ID") 
  ;
--------------------------------------------------------
--  DDL for Index XPK���ϸ���
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK���ϸ���" ON "MILEAGE" ("MIL_CODE", "MEM_ID") 
  ;
--------------------------------------------------------
--  DDL for Index MILEAGE_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "MILEAGE_PK" ON "MILEAGE" ("MIL_DATE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK����
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK����" ON "PAYMENT" ("PAY_NO") 
  ;
--------------------------------------------------------
--  DDL for Index XPK����
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK����" ON "PHOTO" ("PT_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPKȯ��
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPKȯ��" ON "REFUND" ("RF_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK����
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK����" ON "RESERVATION" ("RES_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK����
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK����" ON "REVIEW" ("REV_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK����
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK����" ON "ROOM" ("R_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK���ڼ��񽺻�
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK���ڼ��񽺻�" ON "SERVICE_INFO" ("SI_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK���ڼ���
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK���ڼ���" ON "SERVICE_LIST" ("A_CODE", "SI_CODE") 
  ;
--------------------------------------------------------
--  DDL for Index XPK���ø���Ʈ
--------------------------------------------------------

  CREATE UNIQUE INDEX "XPK���ø���Ʈ" ON "WISHLIST" ("MEM_ID", "A_CODE") 
  ;
--------------------------------------------------------
--  DDL for Trigger ACCOMMODATION_DELETE_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "ACCOMMODATION_DELETE_TRIGGER" 
BEFORE DELETE ON ACCOMMODATION
FOR EACH ROW
BEGIN
    DELETE FROM PHOTO WHERE PT_FILE = :OLD.A_CODE||'_1';
    DELETE FROM PHOTO WHERE PT_FILE = :OLD.A_CODE||'_2';
    DELETE FROM PHOTO WHERE PT_FILE = :OLD.A_CODE||'_3';
END;
/
ALTER TRIGGER "ACCOMMODATION_DELETE_TRIGGER" ENABLE;
--------------------------------------------------------
--  DDL for Trigger ACCOMMODATION_INSERT_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "ACCOMMODATION_INSERT_TRIGGER" 
AFTER INSERT ON ACCOMMODATION
FOR EACH ROW
BEGIN
    INSERT INTO PHOTO (PT_CODE, PT_FILE, PT_TYPE)
    VALUES ('J' || lpad(PH_seq.nextval, 10, '0'), :NEW.A_CODE || '_1', '����');
    INSERT INTO PHOTO (PT_CODE, PT_FILE, PT_TYPE)
    VALUES ('J' || lpad(PH_seq.nextval, 10, '0'), :NEW.A_CODE || '_2', '����');
    INSERT INTO PHOTO (PT_CODE, PT_FILE, PT_TYPE)
    VALUES ('J' || lpad(PH_seq.nextval, 10, '0'), :NEW.A_CODE || '_3', '����');
END;

-----------------------------------------------------------------------------------------------------------
--���� Ʈ����, ���Ҹ� �����ϸ� ���信 �ڵ����� ���һ����� 3�� ������
create or replace TRIGGER ACCOMMODATION_DELETE_TRIGGER
BEFORE DELETE ON ACCOMMODATION
FOR EACH ROW
BEGIN
    DELETE FROM PHOTO WHERE PT_FILE = :OLD.A_CODE||'_1';
    DELETE FROM PHOTO WHERE PT_FILE = :OLD.A_CODE||'_2';
    DELETE FROM PHOTO WHERE PT_FILE = :OLD.A_CODE||'_3';
END;
-----------------------------------------------------------------------------------------------------------
--��� Ʈ����, ����� ����ϸ� ���信 �ڵ����� ������ ������ ��ϵ�
create or replace TRIGGER MEMBER_INSERT_TRIGGER
AFTER update ON MEMBER
FOR EACH ROW
BEGIN 

    INSERT INTO PHOTO (PT_CODE, PT_FILE, PT_TYPE)
        VALUES ('J' || lpad(PH_seq.nextval, 10, '0'), :NEW.MEM_ID, '������');     

END;
----------------------------------------------------------------------------------------------------------
--���ø���Ʈ Ʈ����, ���ø���Ʈ�� �߰��ϸ� �ڵ����� �ش� ȣ���� ���� ���� �þ�� �ȴ�.
create or replace TRIGGER TRG_WISHLIST
AFTER INSERT
ON WISHLIST
FOR EACH ROW
DECLARE
    v_new_wnum NUMBER;
BEGIN
    SELECT NVL(MAX(A_WNUM), 0) + 1 INTO v_new_wnum FROM ACCOMMODATION WHERE A_CODE = :NEW.A_CODE;
    UPDATE ACCOMMODATION SET A_WNUM = v_new_wnum WHERE A_CODE = :NEW.A_CODE;
END;
----------------------------------------------------------------------------------------------------------------------------
--���ø���Ʈ Ʈ����, ���ø���Ʈ�� �����ϸ� �ڵ����� �ش� ȣ���� ���� ���� �پ��� �ȴ�.
CREATE OR REPLACE TRIGGER TRG_WISHLIST_DELETE
AFTER DELETE
ON WISHLIST
FOR EACH ROW
DECLARE
    v_a_code WISHLIST.A_CODE%TYPE;
BEGIN
    v_a_code := :OLD.A_CODE;
    UPDATE ACCOMMODATION
    SET A_WNUM = GREATEST(0, A_WNUM - 1)
    WHERE A_CODE = v_a_code;
END;
-----------------------------------------------------------------------------------------
-- ���ϸ��� Ʈ����, ȸ�������� �ϰԵǸ� �ڵ����� 1000�� �߰��Ѵ�
create or replace TRIGGER TRIG_MILEAGE
AFTER INSERT ON MEMBER
FOR EACH ROW
BEGIN
 INSERT INTO MILEAGE (MIL_CODE, MEM_ID, MIL_HIS, MIL_AMT, MIL_TOTAL, MIL_DATE)
VALUES (('ML23' || lpad(mil_seq.nextval,5,'0')), :new.MEM_ID,'ȸ������', 1000, 1000, SYSDATE);
END;

COMMIT;
/
ALTER TRIGGER "ACCOMMODATION_INSERT_TRIGGER" ENABLE;
--------------------------------------------------------
--  DDL for Trigger MEMBER_INSERT_TRIGGER
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "MEMBER_INSERT_TRIGGER" 
AFTER update ON MEMBER
FOR EACH ROW
BEGIN 

    INSERT INTO PHOTO (PT_CODE, PT_FILE, PT_TYPE)
        VALUES ('J' || lpad(PH_seq.nextval, 10, '0'), :NEW.MEM_ID, '������');     

END;
/
ALTER TRIGGER "MEMBER_INSERT_TRIGGER" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRIG_MILEAGE
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "TRIG_MILEAGE" 
AFTER INSERT ON MEMBER
FOR EACH ROW
BEGIN
 INSERT INTO MILEAGE (MIL_CODE, MEM_ID, MIL_HIS, MIL_AMT, MIL_TOTAL, MIL_DATE)
VALUES (('ML23' || lpad(mil_seq.nextval,5,'0')), :new.MEM_ID,'ȸ������', 1000, 1000, SYSDATE);
END;
/
ALTER TRIGGER "TRIG_MILEAGE" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_WISHLIST_DELETE
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "TRG_WISHLIST_DELETE" 
AFTER DELETE
ON WISHLIST
FOR EACH ROW
DECLARE
    v_a_code WISHLIST.A_CODE%TYPE;
BEGIN
    v_a_code := :OLD.A_CODE;
    UPDATE ACCOMMODATION
    SET A_WNUM = GREATEST(0, A_WNUM - 1)
    WHERE A_CODE = v_a_code;
END;
/
ALTER TRIGGER "TRG_WISHLIST_DELETE" ENABLE;
--------------------------------------------------------
--  DDL for Trigger TRG_WISHLIST
--------------------------------------------------------

  CREATE OR REPLACE TRIGGER "TRG_WISHLIST" 
AFTER INSERT
ON WISHLIST
FOR EACH ROW
DECLARE
    v_new_wnum NUMBER;
BEGIN
    SELECT NVL(MAX(A_WNUM), 0) + 1 INTO v_new_wnum FROM ACCOMMODATION WHERE A_CODE = :NEW.A_CODE;
    UPDATE ACCOMMODATION SET A_WNUM = v_new_wnum WHERE A_CODE = :NEW.A_CODE;
END;
/
ALTER TRIGGER "TRG_WISHLIST" ENABLE;
--------------------------------------------------------
--  Constraints for Table ACCOMMODATION
--------------------------------------------------------

  ALTER TABLE "ACCOMMODATION" ADD CONSTRAINT "XPK���ھ�ü" PRIMARY KEY ("A_CODE") ENABLE;
  ALTER TABLE "ACCOMMODATION" MODIFY ("A_TYPE" NOT NULL ENABLE);
  ALTER TABLE "ACCOMMODATION" MODIFY ("A_EXTIME" NOT NULL ENABLE);
  ALTER TABLE "ACCOMMODATION" MODIFY ("A_ENTIME" NOT NULL ENABLE);
  ALTER TABLE "ACCOMMODATION" MODIFY ("A_WNUM" NOT NULL ENABLE);
  ALTER TABLE "ACCOMMODATION" MODIFY ("A_TEL" NOT NULL ENABLE);
  ALTER TABLE "ACCOMMODATION" MODIFY ("A_ADDR" NOT NULL ENABLE);
  ALTER TABLE "ACCOMMODATION" MODIFY ("A_NAME" NOT NULL ENABLE);
  ALTER TABLE "ACCOMMODATION" MODIFY ("A_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table BOARD
--------------------------------------------------------

  ALTER TABLE "BOARD" ADD CONSTRAINT "XPK�Խ���" PRIMARY KEY ("BO_CODE") ENABLE;
  ALTER TABLE "BOARD" MODIFY ("MEM_ID" NOT NULL ENABLE);
  ALTER TABLE "BOARD" MODIFY ("BO_DATE" NOT NULL ENABLE);
  ALTER TABLE "BOARD" MODIFY ("BO_CONTENT" NOT NULL ENABLE);
  ALTER TABLE "BOARD" MODIFY ("BO_TITLE" NOT NULL ENABLE);
  ALTER TABLE "BOARD" MODIFY ("BO_TYPE" NOT NULL ENABLE);
  ALTER TABLE "BOARD" MODIFY ("BO_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table COMENT
--------------------------------------------------------

  ALTER TABLE "COMENT" ADD CONSTRAINT "XPK���" PRIMARY KEY ("CO_CODE") ENABLE;
  ALTER TABLE "COMENT" MODIFY ("CO_CONTENT" NOT NULL ENABLE);
  ALTER TABLE "COMENT" MODIFY ("BO_CODE" NOT NULL ENABLE);
  ALTER TABLE "COMENT" MODIFY ("CO_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table COUPON
--------------------------------------------------------

  ALTER TABLE "COUPON" ADD CONSTRAINT "XPK����" PRIMARY KEY ("CO_CODE") ENABLE;
  ALTER TABLE "COUPON" MODIFY ("CO_RATE" NOT NULL ENABLE);
  ALTER TABLE "COUPON" MODIFY ("CO_NAME" NOT NULL ENABLE);
  ALTER TABLE "COUPON" MODIFY ("CO_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table CP_HAVING
--------------------------------------------------------

  ALTER TABLE "CP_HAVING" ADD CONSTRAINT "XPK����_������" PRIMARY KEY ("CO_CODE", "MEM_ID", "CP_DATE") ENABLE;
  ALTER TABLE "CP_HAVING" MODIFY ("CP_DATE" NOT NULL ENABLE);
  ALTER TABLE "CP_HAVING" MODIFY ("CP_USE" NOT NULL ENABLE);
  ALTER TABLE "CP_HAVING" MODIFY ("MEM_ID" NOT NULL ENABLE);
  ALTER TABLE "CP_HAVING" MODIFY ("CO_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table GROUPBUYING
--------------------------------------------------------

  ALTER TABLE "GROUPBUYING" ADD CONSTRAINT "XPK��������" PRIMARY KEY ("GB_CODE") ENABLE;
  ALTER TABLE "GROUPBUYING" MODIFY ("GB_DATE" NOT NULL ENABLE);
  ALTER TABLE "GROUPBUYING" MODIFY ("GB_INVEN" NOT NULL ENABLE);
  ALTER TABLE "GROUPBUYING" MODIFY ("GB_CONTENT" NOT NULL ENABLE);
  ALTER TABLE "GROUPBUYING" MODIFY ("GB_TITLE" NOT NULL ENABLE);
  ALTER TABLE "GROUPBUYING" MODIFY ("GB_DPRICE" NOT NULL ENABLE);
  ALTER TABLE "GROUPBUYING" MODIFY ("GB_RPRICE" NOT NULL ENABLE);
  ALTER TABLE "GROUPBUYING" MODIFY ("GB_COUT" NOT NULL ENABLE);
  ALTER TABLE "GROUPBUYING" MODIFY ("GB_CIN" NOT NULL ENABLE);
  ALTER TABLE "GROUPBUYING" MODIFY ("GB_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table MEMBER
--------------------------------------------------------

  ALTER TABLE "MEMBER" ADD CONSTRAINT "XPKȸ��" PRIMARY KEY ("MEM_ID") ENABLE;
  ALTER TABLE "MEMBER" MODIFY ("MEM_CODE" NOT NULL ENABLE);
  ALTER TABLE "MEMBER" MODIFY ("MEM_GENDER" NOT NULL ENABLE);
  ALTER TABLE "MEMBER" MODIFY ("MEM_BIRTH" NOT NULL ENABLE);
  ALTER TABLE "MEMBER" MODIFY ("MEM_TEL" NOT NULL ENABLE);
  ALTER TABLE "MEMBER" MODIFY ("MEM_EMAIL" NOT NULL ENABLE);
  ALTER TABLE "MEMBER" MODIFY ("MEM_NAME" NOT NULL ENABLE);
  ALTER TABLE "MEMBER" MODIFY ("MEM_PASS" NOT NULL ENABLE);
  ALTER TABLE "MEMBER" MODIFY ("MEM_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table MILEAGE
--------------------------------------------------------

  ALTER TABLE "MILEAGE" MODIFY ("MIL_DATE" NOT NULL ENABLE);
  ALTER TABLE "MILEAGE" MODIFY ("MIL_TOTAL" NOT NULL ENABLE);
  ALTER TABLE "MILEAGE" MODIFY ("MIL_AMT" NOT NULL ENABLE);
  ALTER TABLE "MILEAGE" MODIFY ("MIL_HIS" NOT NULL ENABLE);
  ALTER TABLE "MILEAGE" MODIFY ("MEM_ID" NOT NULL ENABLE);
  ALTER TABLE "MILEAGE" MODIFY ("MIL_CODE" NOT NULL ENABLE);
  ALTER TABLE "MILEAGE" ADD CONSTRAINT "MILEAGE_PK" PRIMARY KEY ("MIL_DATE") ENABLE;
--------------------------------------------------------
--  Constraints for Table PAYMENT
--------------------------------------------------------

  ALTER TABLE "PAYMENT" ADD CONSTRAINT "XPK����" PRIMARY KEY ("PAY_NO") ENABLE;
  ALTER TABLE "PAYMENT" MODIFY ("PAY_METHOD" NOT NULL ENABLE);
  ALTER TABLE "PAYMENT" MODIFY ("PAY_PRICE" NOT NULL ENABLE);
  ALTER TABLE "PAYMENT" MODIFY ("PAY_DATE" NOT NULL ENABLE);
  ALTER TABLE "PAYMENT" MODIFY ("RES_CODE" NOT NULL ENABLE);
  ALTER TABLE "PAYMENT" MODIFY ("PAY_NO" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table PHOTO
--------------------------------------------------------

  ALTER TABLE "PHOTO" ADD CONSTRAINT "XPK����" PRIMARY KEY ("PT_CODE") ENABLE;
  ALTER TABLE "PHOTO" MODIFY ("PT_TYPE" NOT NULL ENABLE);
  ALTER TABLE "PHOTO" MODIFY ("PT_FILE" NOT NULL ENABLE);
  ALTER TABLE "PHOTO" MODIFY ("PT_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table REFUND
--------------------------------------------------------

  ALTER TABLE "REFUND" ADD CONSTRAINT "XPKȯ��" PRIMARY KEY ("RF_CODE") ENABLE;
  ALTER TABLE "REFUND" MODIFY ("RF_DATE" NOT NULL ENABLE);
  ALTER TABLE "REFUND" MODIFY ("PAY_NO" NOT NULL ENABLE);
  ALTER TABLE "REFUND" MODIFY ("RF_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table RESERVATION
--------------------------------------------------------

  ALTER TABLE "RESERVATION" ADD CONSTRAINT "XPK����" PRIMARY KEY ("RES_CODE") ENABLE;
  ALTER TABLE "RESERVATION" MODIFY ("RES_STATUS" NOT NULL ENABLE);
  ALTER TABLE "RESERVATION" MODIFY ("RES_COUT" NOT NULL ENABLE);
  ALTER TABLE "RESERVATION" MODIFY ("RES_CIN" NOT NULL ENABLE);
  ALTER TABLE "RESERVATION" MODIFY ("MEM_ID" NOT NULL ENABLE);
  ALTER TABLE "RESERVATION" MODIFY ("R_CODE" NOT NULL ENABLE);
  ALTER TABLE "RESERVATION" MODIFY ("RES_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table REVIEW
--------------------------------------------------------

  ALTER TABLE "REVIEW" MODIFY ("REV_SCORE" NOT NULL ENABLE);
  ALTER TABLE "REVIEW" MODIFY ("REV_DATE" NOT NULL ENABLE);
  ALTER TABLE "REVIEW" MODIFY ("RES_CODE" NOT NULL ENABLE);
  ALTER TABLE "REVIEW" MODIFY ("REV_CODE" NOT NULL ENABLE);
  ALTER TABLE "REVIEW" ADD CONSTRAINT "XPK����" PRIMARY KEY ("REV_CODE") ENABLE;
  ALTER TABLE "REVIEW" MODIFY ("REV_CONTENT" NOT NULL ENABLE);
  ALTER TABLE "REVIEW" MODIFY ("REV_TITLE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table ROOM
--------------------------------------------------------

  ALTER TABLE "ROOM" ADD CONSTRAINT "XPK����" PRIMARY KEY ("R_CODE") ENABLE;
  ALTER TABLE "ROOM" MODIFY ("R_INVEN" NOT NULL ENABLE);
  ALTER TABLE "ROOM" MODIFY ("R_PRICE" NOT NULL ENABLE);
  ALTER TABLE "ROOM" MODIFY ("R_MAX" NOT NULL ENABLE);
  ALTER TABLE "ROOM" MODIFY ("R_MIN" NOT NULL ENABLE);
  ALTER TABLE "ROOM" MODIFY ("R_TYPE" NOT NULL ENABLE);
  ALTER TABLE "ROOM" MODIFY ("A_CODE" NOT NULL ENABLE);
  ALTER TABLE "ROOM" MODIFY ("R_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SERVICE_INFO
--------------------------------------------------------

  ALTER TABLE "SERVICE_INFO" ADD CONSTRAINT "XPK���ڼ��񽺻�" PRIMARY KEY ("SI_CODE") ENABLE;
  ALTER TABLE "SERVICE_INFO" MODIFY ("SI_NAME" NOT NULL ENABLE);
  ALTER TABLE "SERVICE_INFO" MODIFY ("SI_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table SERVICE_LIST
--------------------------------------------------------

  ALTER TABLE "SERVICE_LIST" ADD CONSTRAINT "XPK���ڼ���" PRIMARY KEY ("A_CODE", "SI_CODE") ENABLE;
  ALTER TABLE "SERVICE_LIST" MODIFY ("SI_CODE" NOT NULL ENABLE);
  ALTER TABLE "SERVICE_LIST" MODIFY ("A_CODE" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table WISHLIST
--------------------------------------------------------

  ALTER TABLE "WISHLIST" ADD CONSTRAINT "XPK���ø���Ʈ" PRIMARY KEY ("MEM_ID", "A_CODE") ENABLE;
  ALTER TABLE "WISHLIST" MODIFY ("A_CODE" NOT NULL ENABLE);
  ALTER TABLE "WISHLIST" MODIFY ("MEM_ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table BOARD
--------------------------------------------------------

  ALTER TABLE "BOARD" ADD CONSTRAINT "R_15" FOREIGN KEY ("MEM_ID")
	  REFERENCES "MEMBER" ("MEM_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table COMENT
--------------------------------------------------------

  ALTER TABLE "COMENT" ADD CONSTRAINT "R_33" FOREIGN KEY ("BO_CODE")
	  REFERENCES "BOARD" ("BO_CODE") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table CP_HAVING
--------------------------------------------------------

  ALTER TABLE "CP_HAVING" ADD CONSTRAINT "R_21" FOREIGN KEY ("CO_CODE")
	  REFERENCES "COUPON" ("CO_CODE") ENABLE;
  ALTER TABLE "CP_HAVING" ADD CONSTRAINT "R_22" FOREIGN KEY ("MEM_ID")
	  REFERENCES "MEMBER" ("MEM_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table MILEAGE
--------------------------------------------------------

  ALTER TABLE "MILEAGE" ADD CONSTRAINT "R_09" FOREIGN KEY ("MEM_ID")
	  REFERENCES "MEMBER" ("MEM_ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table PAYMENT
--------------------------------------------------------

  ALTER TABLE "PAYMENT" ADD CONSTRAINT "R_10" FOREIGN KEY ("RES_CODE")
	  REFERENCES "RESERVATION" ("RES_CODE") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table RESERVATION
--------------------------------------------------------

  ALTER TABLE "RESERVATION" ADD CONSTRAINT "R_3" FOREIGN KEY ("MEM_ID")
	  REFERENCES "MEMBER" ("MEM_ID") ENABLE;
  ALTER TABLE "RESERVATION" ADD CONSTRAINT "R_31" FOREIGN KEY ("R_CODE")
	  REFERENCES "ROOM" ("R_CODE") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table REVIEW
--------------------------------------------------------

  ALTER TABLE "REVIEW" ADD CONSTRAINT "R_8" FOREIGN KEY ("RES_CODE")
	  REFERENCES "RESERVATION" ("RES_CODE") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table ROOM
--------------------------------------------------------

  ALTER TABLE "ROOM" ADD CONSTRAINT "R_29" FOREIGN KEY ("A_CODE")
	  REFERENCES "ACCOMMODATION" ("A_CODE") ENABLE;
